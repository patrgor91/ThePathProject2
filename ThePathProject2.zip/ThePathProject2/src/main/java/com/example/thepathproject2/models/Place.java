package com.example.thepathproject2.models;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor

public class Place {

    private String name;
    private String zipcode;
    private String street;
    private String city;
    private PlaceType placeType;
    private List<Comment> comments;
    private List<Note> notes;

}
