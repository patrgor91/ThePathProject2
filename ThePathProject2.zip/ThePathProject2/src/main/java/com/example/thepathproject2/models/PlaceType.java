package com.example.thepathproject2.models;

public enum PlaceType {

    RESTAURANT,
    BAKERY,
    SHOP

}
