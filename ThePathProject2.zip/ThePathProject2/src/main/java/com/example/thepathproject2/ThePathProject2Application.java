package com.example.thepathproject2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ThePathProject2Application {

    public static void main(String[] args) {
        SpringApplication.run(ThePathProject2Application.class, args);
    }

}
