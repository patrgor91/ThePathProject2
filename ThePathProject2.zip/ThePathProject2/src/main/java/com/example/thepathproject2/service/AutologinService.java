package com.example.thepathproject2.service;

public interface AutologinService {

        void autologin(String username);

    }

